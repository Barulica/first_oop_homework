
class Product:

    ios_amount = 0
    android_amount = 0

    def __init__(self, name, price, amount, type):
        self.name = name
        self.price = price
        self.amount = amount
        self.type = type
        if type == "ios":
            Product.ios_amount += amount
        elif type == "android":
            Product.android_amount += amount
        else:
            print("Invalid type")

